#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path
import sys


PROJECT_ROOT = (
    Path(__file__).resolve().parent.parent
)

sys.path.insert(
    0,
    str(PROJECT_ROOT),
)


from network_tools.excel import (
    load_devices,
)

from network_tools.nornir_inventory import (
    generate_nornir_inventory,
)


EXCEL_PATH = (
    PROJECT_ROOT
    / "data"
    / "network_inventory.xlsx"
)

NORNIR_PATH = (
    PROJECT_ROOT
    / "data"
    / "nornir_inventory"
)


def main():

    print()
    print("=" * 60)
    print("          EXCEL → NORNIR INVENTORY")
    print("=" * 60)
    print()

    if not EXCEL_PATH.exists():

        print(
            "ERROR: Excel inventory does not exist:"
        )

        print(
            f"  {EXCEL_PATH}"
        )

        print()
        print(
            "Run discover_network.py first."
        )

        return 1

    devices = load_devices(
        EXCEL_PATH
    )

    print(
        f"Devices found in Excel: "
        f"{len(devices)}"
    )

    generate_nornir_inventory(
        devices,
        NORNIR_PATH,
    )

    print()
    print(
        "Nornir inventory generated."
    )

    print()
    print(
        f"Location:"
    )

    print(
        f"  {NORNIR_PATH}"
    )

    print()

    print(
        "Files:"
    )

    print(
        f"  {NORNIR_PATH / 'hosts.yaml'}"
    )

    print(
        f"  {NORNIR_PATH / 'groups.yaml'}"
    )

    print()
    print("=" * 60)

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )