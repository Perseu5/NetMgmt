#!/usr/bin/env python3

from pathlib import Path
import sys
from getpass import getpass

PROJECT_ROOT = Path(
    __file__
).resolve().parent.parent

sys.path.insert(
    0,
    str(PROJECT_ROOT),
)

from network_tools.credentials import (
    CredentialVault,
    prompt_vault_password,
)


VAULT_PATH = (
    PROJECT_ROOT
    / "data"
    / "credentials.enc"
)


def main():

    print()
    print("=" * 55)
    print("        NETWORK CREDENTIAL VAULT")
    print("=" * 55)
    print()

    vault = CredentialVault(
        VAULT_PATH
    )

    if vault.exists():

        print(
            f"Existing vault: {VAULT_PATH}"
        )
        print()

        action = input(
            "Update the vault? [y/N]: "
        ).strip().lower()

        if action != "y":
            return

        master_password = (
            prompt_vault_password()
        )

        try:
            credentials = vault.load(
                master_password
            )
        except Exception as exc:
            print(f"\nERROR: {exc}")
            return

    else:

        print(
            "No credential vault exists."
        )
        print(
            "Creating a new encrypted vault."
        )
        print()

        master_password = (
            prompt_vault_password(
                confirm=True
            )
        )

        credentials = {}

    print()
    print("RADIUS credentials")
    print("-" * 30)

    radius_username = input(
        "RADIUS username: "
    ).strip()

    radius_password = getpass(
        "RADIUS password: "
    )

    credentials["radius"] = {
        "username": radius_username,
        "password": radius_password,
    }

    print()
    print("Cisco router credentials")
    print("-" * 30)

    cisco_enable = getpass(
        "Cisco enable password: "
    )

    credentials["cisco_router"] = {
        "enable_password": cisco_enable,
    }

    print()
    print("Ruckus ICX credentials")
    print("-" * 30)

    ruckus_enable = getpass(
        "Ruckus ICX enable password: "
    )

    credentials["ruckus_icx"] = {
        "enable_password": ruckus_enable,
    }

    vault.save(
        credentials,
        master_password,
    )

    print()
    print("=" * 55)
    print("Credential vault saved.")
    print()
    print(f"Location:")
    print(f"  {VAULT_PATH}")
    print("=" * 55)
    print()


if __name__ == "__main__":
    main()