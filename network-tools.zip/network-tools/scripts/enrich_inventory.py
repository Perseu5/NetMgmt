#!/usr/bin/env python3

from __future__ import annotations

from pathlib import Path
import sys
from getpass import getpass

from netmiko import ConnectHandler
from netmiko.exceptions import (
    NetmikoAuthenticationException,
    NetmikoTimeoutException,
)
from netmiko.ssh_autodetect import SSHDetect


# ---------------------------------------------------------
# Project paths
# ---------------------------------------------------------

PROJECT_ROOT = (
    Path(__file__).resolve().parent.parent
)

sys.path.insert(
    0,
    str(PROJECT_ROOT),
)


from network_tools.credentials import (
    CredentialVault,
)

from network_tools.excel import (
    load_devices,
    update_device,
)

from network_tools.device_identification import (
    identify_device,
)


VAULT_PATH = (
    PROJECT_ROOT
    / "data"
    / "credentials.enc"
)

INVENTORY_PATH = (
    PROJECT_ROOT
    / "data"
    / "network_inventory.xlsx"
)


# ---------------------------------------------------------
# Supported platforms
# ---------------------------------------------------------

SUPPORTED_DEVICES = {
    "cisco_ios",
    "ruckus_fastiron",
}


# ---------------------------------------------------------
# Device detection
# ---------------------------------------------------------

def autodetect_device(
    ip: str,
    username: str,
    password: str,
) -> str | None:
    """
    Use Netmiko SSHDetect to determine the device platform.

    Returns:
        cisco_ios
        ruckus_fastiron
        None
    """

    parameters = {
        "device_type": "autodetect",
        "host": ip,
        "username": username,
        "password": password,
        "conn_timeout": 10,
        "auth_timeout": 10,
        "banner_timeout": 10,
    }

    detector = SSHDetect(
        **parameters
    )

    try:
        detected = detector.autodetect()

    finally:
        try:
            detector.connection.disconnect()
        except Exception:
            pass

    if detected not in SUPPORTED_DEVICES:
        return None

    return detected


# ---------------------------------------------------------
# Connection parameters
# ---------------------------------------------------------

def build_connection_parameters(
    ip: str,
    username: str,
    password: str,
    device_type: str,
    enable_password: str,
) -> dict:
    """
    Build Netmiko connection parameters.
    """

    return {
        "device_type": device_type,
        "host": ip,
        "username": username,
        "password": password,
        "secret": enable_password,

        "conn_timeout": 10,
        "auth_timeout": 10,
        "banner_timeout": 15,
    }


# ---------------------------------------------------------
# Determine privilege profile
# ---------------------------------------------------------

def get_privilege_profile(
    device_type: str,
) -> str | None:

    if device_type == "cisco_ios":
        return "cisco_router"

    if device_type == "ruckus_fastiron":
        return "ruckus_icx"

    return None


# ---------------------------------------------------------
# Process one device
# ---------------------------------------------------------

def enrich_device(
    device: dict,
    radius: dict,
    credentials: dict,
) -> dict | None:

    ip = device.get(
        "IP Address"
    )

    if not ip:
        return None

    print(
        f"[{ip}]"
    )

    # -----------------------------------------------------
    # Detect platform
    # -----------------------------------------------------

    print(
        "  Detecting platform..."
    )

    try:

        device_type = autodetect_device(
            ip=str(ip),
            username=radius["username"],
            password=radius["password"],
        )

    except NetmikoAuthenticationException:

        print(
            "  ERROR: Authentication failed during detection."
        )

        return None

    except NetmikoTimeoutException:

        print(
            "  ERROR: SSH timeout during detection."
        )

        return None

    except Exception as exc:

        print(
            f"  ERROR: Platform detection failed: {exc}"
        )

        return None

    if not device_type:

        print(
            "  Unsupported or unknown device."
        )

        return None

    print(
        f"  Detected: {device_type}"
    )

    # -----------------------------------------------------
    # Determine privilege profile
    # -----------------------------------------------------

    privilege_profile = get_privilege_profile(
        device_type
    )

    if not privilege_profile:

        print(
            "  ERROR: No privilege profile configured."
        )

        return None

    print(
        f"  Privilege profile: "
        f"{privilege_profile}"
    )

    # -----------------------------------------------------
    # Get enable password
    # -----------------------------------------------------

    profile = credentials.get(
        privilege_profile
    )

    if not profile:

        print(
            f"  ERROR: Credential profile "
            f"'{privilege_profile}' not found."
        )

        return None

    enable_password = profile.get(
        "enable_password"
    )

    if not enable_password:

        print(
            f"  ERROR: Enable password missing "
            f"for '{privilege_profile}'."
        )

        return None

    # -----------------------------------------------------
    # Build Netmiko connection
    # -----------------------------------------------------

    connection_parameters = (
        build_connection_parameters(
            ip=str(ip),
            username=radius["username"],
            password=radius["password"],
            device_type=device_type,
            enable_password=enable_password,
        )
    )

    print(
        "  Connecting..."
    )

    try:

        with ConnectHandler(
            **connection_parameters
        ) as connection:

            # -------------------------------------------------
            # Enter enable / privileged mode
            # -------------------------------------------------

            print(
                "  Entering privileged mode..."
            )

            connection.enable()

            # -------------------------------------------------
            # Collect inventory
            # -------------------------------------------------

            print(
                "  Collecting device information..."
            )

            information = identify_device(
                connection,
                device_type,
            )

            # -------------------------------------------------
            # Make sure these values are always present
            # -------------------------------------------------

            information[
                "Privilege Profile"
            ] = privilege_profile

            information[
                "Ping Status"
            ] = "Responding"

            return information

    except NetmikoAuthenticationException:

        print(
            "  ERROR: Authentication failed."
        )

    except NetmikoTimeoutException:

        print(
            "  ERROR: Connection timeout."
        )

    except Exception as exc:

        print(
            f"  ERROR: {exc}"
        )

    return None


# ---------------------------------------------------------
# Main
# ---------------------------------------------------------

def main():

    print()
    print("=" * 60)
    print("          NETWORK INVENTORY ENRICHMENT")
    print("=" * 60)
    print()

    # -----------------------------------------------------
    # Check files
    # -----------------------------------------------------

    if not VAULT_PATH.exists():

        print(
            "ERROR: Credential vault not found:"
        )

        print(
            f"  {VAULT_PATH}"
        )

        print()

        print(
            "Run create_credentials.py first."
        )

        return 1

    if not INVENTORY_PATH.exists():

        print(
            "ERROR: Excel inventory not found:"
        )

        print(
            f"  {INVENTORY_PATH}"
        )

        print()

        print(
            "Run discover_network.py first."
        )

        return 1

    # -----------------------------------------------------
    # Load encrypted credentials
    # -----------------------------------------------------

    vault = CredentialVault(
        VAULT_PATH
    )

    master_password = getpass(
        "Vault password: "
    )

    try:

        credentials = vault.load(
            master_password
        )

    except Exception as exc:

        print()
        print(
            f"ERROR: Could not open credential vault: {exc}"
        )

        return 1

    # -----------------------------------------------------
    # Verify RADIUS credentials
    # -----------------------------------------------------

    radius = credentials.get(
        "radius"
    )

    if not radius:

        print()
        print(
            "ERROR: RADIUS credentials are missing "
            "from the vault."
        )

        return 1

    radius_username = radius.get(
        "username"
    )

    radius_password = radius.get(
        "password"
    )

    if not radius_username or not radius_password:

        print()
        print(
            "ERROR: RADIUS username/password is incomplete."
        )

        return 1

    # -----------------------------------------------------
    # Load Excel inventory
    # -----------------------------------------------------

    devices = load_devices(
        INVENTORY_PATH
    )

    if not devices:

        print(
            "No devices found in the Excel inventory."
        )

        return 0

    print()
    print(
        f"Devices in inventory: {len(devices)}"
    )

    print()

    # -----------------------------------------------------
    # Statistics
    # -----------------------------------------------------

    successful = 0
    failed = 0
    unsupported = 0

    # -----------------------------------------------------
    # Process devices
    # -----------------------------------------------------

    for device in devices:

        ip = device.get(
            "IP Address"
        )

        if not ip:
            continue

        result = enrich_device(
            device=device,
            radius=radius,
            credentials=credentials,
        )

        if result is None:

            failed += 1

            print()

            continue

        # -------------------------------------------------
        # Update Excel
        # -------------------------------------------------

        update_device(
            INVENTORY_PATH,
            str(ip),
            result,
        )

        successful += 1

        print(
            "  Inventory information:"
        )

        print(
            f"    Hostname: "
            f"{result.get('Hostname') or 'Unknown'}"
        )

        print(
            f"    Vendor: "
            f"{result.get('Vendor') or 'Unknown'}"
        )

        print(
            f"    Platform: "
            f"{result.get('Platform') or 'Unknown'}"
        )

        print(
            f"    Device Type: "
            f"{result.get('Device Type') or 'Unknown'}"
        )

        print(
            f"    Model: "
            f"{result.get('Model') or 'Unknown'}"
        )

        print(
            f"    Serial: "
            f"{result.get('Serial Number') or 'Unknown'}"
        )

        print(
            f"    OS Version: "
            f"{result.get('OS Version') or 'Unknown'}"
        )

        print()

    # -----------------------------------------------------
    # Summary
    # -----------------------------------------------------

    print()
    print("=" * 60)
    print("Inventory enrichment complete.")
    print("=" * 60)

    print()
    print(
        f"Successful: {successful}"
    )

    print(
        f"Failed:     {failed}"
    )

    print()
    print(
        "Excel inventory:"
    )

    print(
        f"  {INVENTORY_PATH}"
    )

    print()

    return 0


if __name__ == "__main__":
    raise SystemExit(
        main()
    )