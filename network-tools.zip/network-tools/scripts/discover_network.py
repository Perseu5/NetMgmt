#!/usr/bin/env python3

from pathlib import Path
import sys
import time

PROJECT_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT_ROOT))

from network_tools.discovery import (
    validate_network,
    scan_network,
)

from network_tools.excel import create_inventory


INVENTORY_PATH = (
    PROJECT_ROOT
    / "data"
    / "network_inventory.xlsx"
)


def main():
    print()
    print("=" * 50)
    print("       NETWORK DISCOVERY TOOL")
    print("=" * 50)
    print()

    network_input = input(
        "Enter network range: "
    ).strip()

    try:
        network = validate_network(network_input)
    except ValueError as exc:
        print(f"\nERROR: {exc}")
        return

    total_hosts = network.num_addresses - 2

    if total_hosts < 1:
        print("Network does not contain usable host addresses.")
        return

    print()
    print(f"Network: {network}")
    print(f"Addresses to scan: {total_hosts}")
    print()

    start = time.monotonic()

    print("Scanning...")

    results = scan_network(network)

    responding = [
        result.ip
        for result in results
        if result.responding
    ]

    elapsed = time.monotonic() - start

    print()
    print("=" * 50)
    print(f"Scan complete.")
    print(f"Hosts scanned: {len(results)}")
    print(f"Hosts responding: {len(responding)}")
    print(f"Scan duration: {elapsed:.2f} seconds")
    print("=" * 50)

    print()
    print("Responding hosts:")

    for ip in responding:
        print(f"  {ip}")

    print()
    print("Creating Excel inventory...")

    create_inventory(
        path=INVENTORY_PATH,
        network_range=str(network),
        responding_ips=responding,
    )

    print()
    print(f"Inventory created:")
    print(f"  {INVENTORY_PATH}")
    print()


if __name__ == "__main__":
    main()