from __future__ import annotations

import concurrent.futures
import ipaddress
import platform
import subprocess
from dataclasses import dataclass
from typing import Iterable


@dataclass
class PingResult:
    ip: str
    responding: bool
    error: str = ""


def validate_network(network_string: str) -> ipaddress.IPv4Network:
    try:
        network = ipaddress.ip_network(
            network_string.strip(),
            strict=False,
        )
    except ValueError as exc:
        raise ValueError(
            f"Invalid network: {network_string}"
        ) from exc

    if network.version != 4:
        raise ValueError("Only IPv4 networks are supported in V1.")

    return network


def ping_host(ip: str, timeout: int = 1) -> PingResult:
    system = platform.system().lower()

    if system == "linux":
        command = [
            "ping",
            "-c",
            "1",
            "-W",
            str(timeout),
            ip,
        ]
    elif system == "darwin":
        command = [
            "ping",
            "-c",
            "1",
            "-W",
            str(timeout * 1000),
            ip,
        ]
    else:
        command = [
            "ping",
            "-n",
            "1",
            "-w",
            str(timeout * 1000),
            ip,
        ]

    try:
        result = subprocess.run(
            command,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=timeout + 2,
        )

        return PingResult(
            ip=ip,
            responding=result.returncode == 0,
        )

    except subprocess.TimeoutExpired:
        return PingResult(
            ip=ip,
            responding=False,
            error="Ping timeout",
        )

    except Exception as exc:
        return PingResult(
            ip=ip,
            responding=False,
            error=str(exc),
        )


def scan_network(
    network: ipaddress.IPv4Network,
    workers: int = 64,
) -> list[PingResult]:

    hosts: Iterable[ipaddress.IPv4Address]

    # Don't normally ping the network/broadcast addresses.
    hosts = network.hosts()

    results = []

    with concurrent.futures.ThreadPoolExecutor(
        max_workers=workers
    ) as executor:

        futures = [
            executor.submit(
                ping_host,
                str(ip),
            )
            for ip in hosts
        ]

        for future in concurrent.futures.as_completed(futures):
            results.append(future.result())

    return sorted(
        results,
        key=lambda result: ipaddress.ip_address(result.ip),
    )