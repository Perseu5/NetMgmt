INSTALL REQUIREMENTS:
pip install -r requirements.txt

chmod +x for pithing scripts if needed.





run scripts/create_credentials.py (creates data/credentials.enc)
run scripts/discover_network.py (generates data/network_inventory.xlsx)
run scripts/enrich_inventory.py (adds to data/network_inventory.xlsx)
run python scripts/excel_to_nornir.py (generates dat/nornir_inventory/hosts.yaml and groups.yaml from network_inventory.xlsx)