from __future__ import annotations

import re
from typing import Any


def clean(value: str | None) -> str:
    if value is None:
        return ""

    return value.strip()


def first_match(
    pattern: str,
    text: str,
    flags: int = re.IGNORECASE,
) -> str:
    match = re.search(pattern, text, flags)

    if not match:
        return ""

    if match.lastindex:
        return clean(match.group(1))

    return clean(match.group(0))


def identify_cisco(
    connection,
    parsed_version: Any | None = None,
) -> dict[str, str]:

    raw = connection.send_command(
        "show version",
        read_timeout=20,
    )

    hostname = first_match(
        r"^(\S+)\s+uptime is",
        raw,
        re.MULTILINE,
    )

    # Cisco IOS/IOS-XE version.
    os_version = first_match(
        r"Version\s+([^,\s]+)",
        raw,
    )

    # Common Cisco hardware identifiers.
    model = first_match(
        r"[Cc]isco\s+(\S+)\s+\(",
        raw,
    )

    if not model:
        model = first_match(
            r"[Cc]isco\s+(\S+)\s+processor",
            raw,
        )

    serial = ""

    # Some Cisco platforms expose a Processor board ID.
    serial = first_match(
        r"Processor board ID\s+(\S+)",
        raw,
    )

    # Newer platforms may expose chassis serial information.
    if not serial:
        serial = first_match(
            r"System Serial Number\s*:\s*(\S+)",
            raw,
        )

    return {
        "Hostname": hostname,
        "Vendor": "Cisco",
        "Platform": "IOS/IOS-XE",
        "Device Type": "Router",
        "Model": model,
        "Serial Number": serial,
        "OS Version": os_version,
        "Privilege Profile": "cisco_router",
    }


def identify_ruckus_icx(
    connection,
) -> dict[str, str]:

    raw = connection.send_command(
        "show version",
        read_timeout=20,
    )

    hostname = ""

    # FastIron prompt generally contains the hostname.
    try:
        prompt = connection.find_prompt().strip()

        if prompt:
            hostname = prompt.rstrip("#>").strip()

    except Exception:
        pass

    # Example:
    #
    # SW: Version 08.0.95...
    #
    os_version = first_match(
        r"SW:\s+Version\s+([^\s]+)",
        raw,
    )

    # Example:
    #
    # HW: Stackable ICX7450-24
    #
    model = first_match(
        r"HW:\s+(?:Stackable\s+)?([A-Za-z0-9-]+)",
        raw,
    )

    # Example:
    #
    # Serial #:CYT3346K035
    #
    serial = first_match(
        r"Serial\s+#:\s*([A-Za-z0-9]+)",
        raw,
    )

    # If the device has multiple stack units, the first serial
    # number found is used for the inventory record.
    if not serial:
        serial = first_match(
            r"Serial\s+#\s*:\s*([A-Za-z0-9]+)",
            raw,
        )

    return {
        "Hostname": hostname,
        "Vendor": "Ruckus",
        "Platform": "FastIron",
        "Device Type": "Switch",
        "Model": model,
        "Serial Number": serial,
        "OS Version": os_version,
        "Privilege Profile": "ruckus_icx",
    }


def identify_device(
    connection,
    device_type: str,
) -> dict[str, str]:

    if device_type == "cisco_ios":
        return identify_cisco(connection)

    if device_type == "ruckus_fastiron":
        return identify_ruckus_icx(connection)

    raise ValueError(
        f"Unsupported device type: {device_type}"
    )