from __future__ import annotations

from pathlib import Path
from typing import Iterable

import yaml


PLATFORM_MAP = {
    "cisco_ios": "cisco_ios",
    "ruckus_fastiron": "ruckus_fastiron",
}


def determine_platform(device: dict) -> str | None:
    """
    Determine the Netmiko platform from inventory data.
    """

    platform = device.get("Platform")

    vendor = str(
        device.get("Vendor") or ""
    ).lower()

    device_type = str(
        device.get("Device Type") or ""
    ).lower()

    if platform:
        platform_lower = str(
            platform
        ).lower()

        if (
            "ios" in platform_lower
            or "ios-xe" in platform_lower
        ):
            return "cisco_ios"

        if (
            "fastiron" in platform_lower
            or "icx" in platform_lower
        ):
            return "ruckus_fastiron"

    if vendor == "cisco":
        return "cisco_ios"

    if vendor == "ruckus":
        return "ruckus_fastiron"

    if (
        vendor == "cisco"
        and device_type == "router"
    ):
        return "cisco_ios"

    if (
        vendor == "ruckus"
        and device_type == "switch"
    ):
        return "ruckus_fastiron"

    return None


def generate_nornir_inventory(
    devices: Iterable[dict],
    output_directory: Path,
) -> None:

    output_directory = Path(
        output_directory
    )

    output_directory.mkdir(
        parents=True,
        exist_ok=True,
    )

    hosts = {}
    groups = {}

    for device in devices:

        ip_address = device.get(
            "IP Address"
        )

        if not ip_address:
            continue

        hostname = (
            device.get("Hostname")
            or str(ip_address)
        )

        platform = determine_platform(
            device
        )

        if not platform:
            continue

        privilege_profile = (
            device.get(
                "Privilege Profile"
            )
            or ""
        )

        host_data = {
            "hostname": str(
                ip_address
            ),
            "platform": platform,

            "data": {
                "vendor": (
                    device.get("Vendor")
                    or ""
                ),

                "device_type": (
                    device.get(
                        "Device Type"
                    )
                    or ""
                ),

                "model": (
                    device.get("Model")
                    or ""
                ),

                "serial_number": (
                    device.get(
                        "Serial Number"
                    )
                    or ""
                ),

                "os_version": (
                    device.get(
                        "OS Version"
                    )
                    or ""
                ),

                "privilege_profile": (
                    privilege_profile
                ),
            },
        }

        hosts[str(hostname)] = host_data

    # Groups are deliberately simple.
    #
    # Credentials will NOT be stored here.

    groups["cisco"] = {
        "data": {
            "vendor": "Cisco",
        }
    }

    groups["ruckus"] = {
        "data": {
            "vendor": "Ruckus",
        }
    }

    hosts_path = (
        output_directory
        / "hosts.yaml"
    )

    groups_path = (
        output_directory
        / "groups.yaml"
    )

    with open(
        hosts_path,
        "w",
        encoding="utf-8",
    ) as file:

        yaml.safe_dump(
            hosts,
            file,
            sort_keys=False,
            default_flow_style=False,
        )

    with open(
        groups_path,
        "w",
        encoding="utf-8",
    ) as file:

        yaml.safe_dump(
            groups,
            file,
            sort_keys=False,
            default_flow_style=False,
        )