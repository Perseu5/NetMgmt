from __future__ import annotations

from datetime import datetime
from pathlib import Path
from typing import Iterable

from openpyxl import Workbook, load_workbook
from openpyxl.formatting.rule import CellIsRule
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.worksheet.datavalidation import DataValidation


DEVICE_HEADERS = [
    "IP Address",
    "Hostname",
    "Ping Status",
    "Vendor",
    "Platform",
    "Device Type",
    "Model",
    "Serial Number",
    "OS Version",
    "Privilege Profile",
    "Notes",
]


PRIVILEGE_PROFILES = [
    "cisco_router",
    "ruckus_icx",
]


def style_header(
    worksheet,
    row: int,
    color: str,
):
    for cell in worksheet[row]:

        cell.font = Font(
            bold=True,
            color="FFFFFF",
        )

        cell.fill = PatternFill(
            "solid",
            fgColor=color,
        )

        cell.alignment = Alignment(
            horizontal="center",
        )


def create_inventory(
    path: Path,
    network_range: str,
    responding_ips: Iterable[str],
):
    path.parent.mkdir(
        parents=True,
        exist_ok=True,
    )

    responding_ips = list(responding_ips)

    workbook = Workbook()

    devices = workbook.active
    devices.title = "Devices"

    scan = workbook.create_sheet(
        "Scan Information"
    )

    errors = workbook.create_sheet(
        "Errors"
    )

    # --------------------------------------------------
    # Devices
    # --------------------------------------------------

    for column, header in enumerate(
        DEVICE_HEADERS,
        start=1,
    ):
        devices.cell(
            row=1,
            column=column,
            value=header,
        )

    style_header(
        devices,
        1,
        "1F4E78",
    )

    for row, ip in enumerate(
        responding_ips,
        start=2,
    ):
        devices.cell(
            row=row,
            column=1,
            value=ip,
        )

        devices.cell(
            row=row,
            column=3,
            value="Responding",
        )

    devices.freeze_panes = "A2"

    devices.auto_filter.ref = (
        f"A1:K{max(devices.max_row, 2)}"
    )

    # --------------------------------------------------
    # Privilege profile dropdown
    # --------------------------------------------------

    profile_validation = DataValidation(
        type="list",
        formula1=(
            '"'
            + ",".join(PRIVILEGE_PROFILES)
            + '"'
        ),
        allow_blank=True,
    )

    profile_validation.error = (
        "Select a valid privilege profile."
    )

    profile_validation.errorTitle = (
        "Invalid Profile"
    )

    devices.add_data_validation(
        profile_validation
    )

    profile_validation.add(
        "J2:J1048576"
    )

    # --------------------------------------------------
    # Ping formatting
    # --------------------------------------------------

    green_fill = PatternFill(
        "solid",
        fgColor="C6EFCE",
    )

    devices.conditional_formatting.add(
        "C2:C1048576",
        CellIsRule(
            operator="equal",
            formula=['"Responding"'],
            fill=green_fill,
        ),
    )

    # --------------------------------------------------
    # Scan information
    # --------------------------------------------------

    scan_data = [
        (
            "Network Range",
            network_range,
        ),
        (
            "Scan Date",
            datetime.now().strftime(
                "%Y-%m-%d %H:%M:%S"
            ),
        ),
        (
            "Total Hosts Responding",
            len(responding_ips),
        ),
    ]

    for row, (key, value) in enumerate(
        scan_data,
        start=1,
    ):
        scan.cell(
            row=row,
            column=1,
            value=key,
        )

        scan.cell(
            row=row,
            column=2,
            value=value,
        )

        scan.cell(
            row=row,
            column=1,
        ).font = Font(bold=True)

    # --------------------------------------------------
    # Errors
    # --------------------------------------------------

    error_headers = [
        "IP Address",
        "Stage",
        "Error",
    ]

    for column, header in enumerate(
        error_headers,
        start=1,
    ):
        errors.cell(
            row=1,
            column=column,
            value=header,
        )

    style_header(
        errors,
        1,
        "C00000",
    )

    # --------------------------------------------------
    # Column widths
    # --------------------------------------------------

    widths = {
        "A": 18,
        "B": 25,
        "C": 15,
        "D": 15,
        "E": 18,
        "F": 18,
        "G": 22,
        "H": 22,
        "I": 20,
        "J": 22,
        "K": 40,
    }

    for column, width in widths.items():
        devices.column_dimensions[
            column
        ].width = width

    scan.column_dimensions["A"].width = 30
    scan.column_dimensions["B"].width = 40

    errors.column_dimensions["A"].width = 18
    errors.column_dimensions["B"].width = 20
    errors.column_dimensions["C"].width = 60

    workbook.save(path)


def load_devices(
    path: Path,
) -> list[dict]:

    workbook = load_workbook(
        path
    )

    worksheet = workbook["Devices"]

    headers = [
        cell.value
        for cell in worksheet[1]
    ]

    devices = []

    for row in worksheet.iter_rows(
        min_row=2,
        values_only=True,
    ):
        if not row[0]:
            continue

        devices.append(
            dict(
                zip(headers, row)
            )
        )

    return devices


def update_device(
    path: Path,
    ip_address: str,
    values: dict,
):
    workbook = load_workbook(
        path
    )

    worksheet = workbook["Devices"]

    headers = {
        cell.value: cell.column
        for cell in worksheet[1]
    }

    for row in range(
        2,
        worksheet.max_row + 1,
    ):

        ip = worksheet.cell(
            row=row,
            column=headers["IP Address"],
        ).value

        if str(ip) != str(ip_address):
            continue

        for key, value in values.items():

            if key not in headers:
                continue

            worksheet.cell(
                row=row,
                column=headers[key],
                value=value,
            )

        break

    workbook.save(path)