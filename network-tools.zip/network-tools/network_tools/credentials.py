from __future__ import annotations

import base64
import json
import os
from getpass import getpass
from pathlib import Path
from typing import Any

from cryptography.fernet import Fernet, InvalidToken
from cryptography.hazmat.primitives.kdf.scrypt import Scrypt


DEFAULT_VAULT = Path("data/credentials.enc")
SALT_LENGTH = 16


class CredentialVault:
    """Encrypted network credential vault."""

    def __init__(self, path: Path = DEFAULT_VAULT):
        self.path = Path(path)

    @staticmethod
    def _derive_key(password: str, salt: bytes) -> bytes:
        kdf = Scrypt(
            salt=salt,
            length=32,
            n=2**14,
            r=8,
            p=1,
        )

        key = kdf.derive(password.encode("utf-8"))
        return base64.urlsafe_b64encode(key)

    def _encrypt(
        self,
        data: dict[str, Any],
        password: str,
    ) -> bytes:
        salt = os.urandom(SALT_LENGTH)

        key = self._derive_key(password, salt)
        cipher = Fernet(key)

        plaintext = json.dumps(
            data,
            indent=2,
        ).encode("utf-8")

        encrypted = cipher.encrypt(plaintext)

        return salt + encrypted

    def _decrypt(
        self,
        data: bytes,
        password: str,
    ) -> dict[str, Any]:

        if len(data) <= SALT_LENGTH:
            raise ValueError("Invalid credential vault.")

        salt = data[:SALT_LENGTH]
        encrypted = data[SALT_LENGTH:]

        key = self._derive_key(password, salt)
        cipher = Fernet(key)

        try:
            plaintext = cipher.decrypt(encrypted)
        except InvalidToken as exc:
            raise ValueError(
                "Incorrect vault password or corrupted vault."
            ) from exc

        return json.loads(
            plaintext.decode("utf-8")
        )

    def exists(self) -> bool:
        return self.path.exists()

    def create(
        self,
        credentials: dict[str, Any],
        password: str,
    ) -> None:

        self.path.parent.mkdir(
            parents=True,
            exist_ok=True,
        )

        encrypted = self._encrypt(
            credentials,
            password,
        )

        with open(self.path, "wb") as file:
            file.write(encrypted)

        # Owner read/write only.
        os.chmod(self.path, 0o600)

    def load(
        self,
        password: str,
    ) -> dict[str, Any]:

        if not self.path.exists():
            raise FileNotFoundError(
                f"Vault not found: {self.path}"
            )

        with open(self.path, "rb") as file:
            encrypted = file.read()

        return self._decrypt(
            encrypted,
            password,
        )

    def save(
        self,
        credentials: dict[str, Any],
        password: str,
    ) -> None:
        self.create(
            credentials,
            password,
        )


def prompt_vault_password(
    confirm: bool = False,
) -> str:

    password = getpass(
        "Vault password: "
    )

    if not password:
        raise ValueError(
            "Vault password cannot be empty."
        )

    if confirm:
        confirmation = getpass(
            "Confirm vault password: "
        )

        if password != confirmation:
            raise ValueError(
                "Vault passwords do not match."
            )

    return password